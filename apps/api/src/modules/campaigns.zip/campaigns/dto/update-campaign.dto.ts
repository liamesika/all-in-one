import { CreateCampaignDto } from './create-campaign.dto';

export class UpdateCampaignDto implements Partial<CreateCampaignDto> {}
